<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'markecgk_wp853');

/** MySQL database username */
define('DB_USER', 'markecgk_wp853');

/** MySQL database password */
define('DB_PASSWORD', 'Sp)3p!7Af8');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'asfvn5f0ufmdlbaoz1cdvcqqwx6ael2o00xauumo05zdztpc3xzyaocc6nlzlfvi');
define('SECURE_AUTH_KEY',  '6kgsqtdpcbnnvfuyijmcwqrefm217nzgq8gh6faegwklbwrrcalcijyoliodgjdv');
define('LOGGED_IN_KEY',    'enxlnop0zpayusw5lvy7zf0xojotnanyghxvwd9iiynp7nuplvckv9ajyw7yuyo0');
define('NONCE_KEY',        'h12vhib5wdudz17e8i22cwftbube1wt5jwgm3nidtaeb2voevbf4luamqaeyzm1d');
define('AUTH_SALT',        '9ur8zl8a8mic1ok4wwccybwsljmtm6csxggn0tecjcotl4iaodoqfibzbwssjvia');
define('SECURE_AUTH_SALT', 'orittp61bn7nc6zkqbrjelqumvyxzgqnfpnr0efyjj3vx5cqdczd7s3jdh9ocfrs');
define('LOGGED_IN_SALT',   '0swiq4aaaqeftbjxoxfsgxiyfmh5p17i5pajdfo5uts1fxwkzsa7uwos3zdjjugc');
define('NONCE_SALT',       'trhwg9mzhmqzpscn7ima1xjq887s4oqfthmyayr2vjpr2uca5ege9r66bij2hlmu');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpsr_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
